<?php

namespace App\Services\Business;

use Carbon\Carbon;
use App\Models\Sla;
use App\Models\Plan;
use App\Models\User;
use App\Enum\UserRole;
use App\Models\Company;
use App\Enum\UserStatus;
use App\Mail\NewUserMail;
use App\Traits\ApiResponder;
use App\Mail\EmailInvitation;
use App\Mail\EmailVerification;
use App\Models\IndividualProfile;
use App\Models\UserSubscription;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use PhpOffice\PhpSpreadsheet\IOFactory;

class EmployeeService
{
    use ApiResponder;
    public static function getAllEmployees()
    {
        $user = Auth::user();
        return User::where('company_id', $user->company->id)->where('id', '!=', $user->id)->latest('id')->get();
    }

    public function store($data)
    {
        $user = Auth::user();
        $sla = Sla::where('user_id', $user->id)->first();
        $plan = Plan::where('id', $user->plan_id)->first();
        $employees = User::where('company_id', $user->company_id)->count();
        if ($employees >= ($plan->number_of_users)) {
            return $this->errorResponse('Opps! You have reached the maximum numbers of user for your paln', 422);
        }
        $employee = '';
        DB::beginTransaction();
        if ($data) {
            $employee = User::create([
                'email' => strtolower($data->email),
                'password' => Hash::make('password12345'),
                'role' => UserRole::INDIVIDUAL,
                'email_verified_at' => now(),
                'company_id' => $user->company->id
            ]);

            IndividualProfile::create([
                'user_id' => $employee->id,
                'first_name' => $data->first_name,
                'last_name' => $data->last_name,
                'email' => $data->email,
                'gender' => $data->gender,
                'current_role' => $data->current_role,
                'target_role' => $data->target_role,
                'specialization' => $data->specialization,
            ]);
            Sla::create([
                'user_id' => $employee->id,
                'sla_id' => $sla->sla_id,
            ]);

            if ($employee) {
                DB::commit();
                $detail = [
                    'name' => $user->company->name,
                    'email' => $employee->email,
                    'password' => 'password12345'
                ];
                if ($employee) Mail::to($employee->email)->send(new EmailInvitation($detail));
                return $employee;
            }
        }

        DB::rollBack();
        return $this->errorResponse('Opps! Something went wrong, your request could not be processed', 422);
    }

    public function emailInvitaion($data)
    {
        $user = Auth::user();
        $employees = User::where('company_id', $user->company_id)->count();
        $plan = Plan::where('id', $user->plan_id)->first();

        if (count($data->email) >= $plan->number_of_users) {
            return $this->errorResponse('Opps! You are only allowed to have ' . $plan->number_of_users . ' users based on your plan', 422);
        }
        DB::beginTransaction();
        try {
            for ($i = 0; $i < count($data->email); $i++) {
                $email = User::where('email', $data->email[$i])->first();
                if ($email) {
                    return $this->errorResponse('Email already taken', 422);
                }
                if ($employees >= ($plan->number_of_users)) {
                    return $this->errorResponse('Opps! You have reached the maximum numbers of user for your paln', 422);
                }
                $employee = User::create([
                    'email' => $data->email[$i],
                    'company_id' => $user->company->id,
                    'password' => Hash::make('password12345'),
                    'role' => UserRole::INDIVIDUAL,
                    'email_verified_at' => now(),
                    'status' => 'active',
                ]);
                IndividualProfile::create([
                    'user_id' => $employee->id,
                    'email' => $data->email[$i],
                ]);

                $detail = [
                    'name' => $user->company->name,
                    'email' => $employee->email,
                    'password' => 'password12345'
                ];
                if ($employee) Mail::to($employee->email)->send(new EmailInvitation($detail));

                set_time_limit(60 * 60);
            }


            DB::commit();
            return $this->successResponse('Invitation Sent successfully', 200);
        } catch (\Exception $e) {
            return $e;
            DB::rollBack();
            return $this->errorResponse('Opps! Something went wrong, your request could not be processed', 422);
        }
    }
    public function UploadEmployees($data)
    {
        $user = Auth::user();
        // Load the file
        $file = $data->file('file');
        $plan = Plan::where('id', $user->plan_id)->first();
        $employees = User::where('company_id', $user->company_id)->count();

        if (count($data) >= $plan->number_of_users) {
            return $this->errorResponse('Opps! You are only allowed to have ' . $plan->number_of_users . ' users based on your plan', 422);
        }
        if ($data->file) {
            DB::beginTransaction();
            try {

                $spreadsheet = IOFactory::load($file->getPathname());

                // Get the first worksheet
                $sheet = $spreadsheet->getActiveSheet();

                // Loop through rows and store data
                foreach ($sheet->getRowIterator(2) as $row) { // Start from row 2 (skip header)
                    $cellIterator = $row->getCellIterator();
                    $cellIterator->setIterateOnlyExistingCells(false);

                    $rowData = [];
                    foreach ($cellIterator as $cell) {
                        $rowData[] = $cell->getValue();
                    }
                    $email = User::where('email', $rowData[2])->first();
                    if ($employees >= ($plan->number_of_users)) {
                        return $this->errorResponse('Opps! You have reached the maximum numbers of user for your paln', 422);
                    }
                    if ($email) {
                        return $this->errorResponse('Email already exist', 422);
                    }

                    // Create account for the employee
                    $employee = User::create([
                        'email' => strtolower($rowData[2]),
                        'password' => Hash::make('password12345'),
                        'role' => UserRole::INDIVIDUAL,
                        'email_verified_at' => now()->toDateString(),
                        'company_id' => $user->company->id
                    ]);

                    // Create employee profile
                    IndividualProfile::create([
                        'user_id' => $employee->id,
                        'first_name' => $rowData[0],
                        'last_name' => $rowData[1],
                        'email' => $rowData[2],
                        'specialization' => $rowData[3],
                        'current_role' => $rowData[4],
                        'target_role' => $rowData[5],
                    ]);

                    $detail = [
                        'name' => $user->company->name,
                        'email' => $rowData[2],
                        'password' => 'password12345'
                    ];

                    if ($employee) Mail::to($employee->email)->send(new EmailInvitation($detail));
                    set_time_limit(60 * 60);
                }
                DB::commit();
                return $this->successResponse('File imported successfully', 200);
            } catch (\Exception $e) {
                return $e;
                DB::rollBack();
            }
            return $this->errorResponse('File Upload failed', 422);
        }
    }

    public function delete($id)
    {
        $user = Auth::user();
        $employee = User::where('company_id', $user->company->id)->find($id);

        if ($id == $user->id) return $this->errorResponse('This user can not be deleted', 422);
        if (!$employee) return $this->errorResponse('No record found', 422);

        $employee->delete();
        return $this->successResponse('Employee deleted', 200);
    }
    public function deactivateEmployeeAccount($id)
    {
        $user = Auth::user();
        $employee = User::where('company_id', $user->company->id)->findOrFail($id);

        if ($id == $user->id) return $this->errorResponse('This user can not be deleted', 422);
        if (!$employee) return $this->errorResponse('No record found', 422);

        $employee->update([
            'status' => UserStatus::SUSPENDED
        ]);
        return $this->successResponse('Employee account de-activated', 200);
    }

    public function bulkDelete($data)
    {
        $user = Auth::user();
        $employees = User::whereIn('id', $data->user_ids)->where('company_id', $user->company->id)->get();
        if ($employees->isEmpty()) {
            return $this->errorResponse('No record found', 422);
        }
        foreach ($employees as $employee) {
            if ($employee->id == $user->id) return $this->errorResponse('This user can not be deleted', 422);
            $employee->save();
            $employee->delete();
        }

        return $this->successResponse('Employees deleted Successfully', 200);
    }
}
